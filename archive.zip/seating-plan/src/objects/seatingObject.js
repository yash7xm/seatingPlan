class SeatingObject {
  constructor(options, canvas, idx) {
    this.rows = options.rows;
    this.rowLength = options.rowLength;
    this.seatRadius = options.seatRadius;
    this.seatSpacing = options.seatSpacing;
    this.grpArr = [];
    this.seatGroups = [];
    this.canvasRef = canvas;
    this.groupAdded = true;
    this.group = null;
    this.idx = idx;
  }

  createSeats() {
    const { rowLength, rows, seatRadius, seatSpacing, canvasRef } = this;

    for (let row = 0; row < rows; row++) {
      for (let seat = 0; seat < rowLength; seat++) {
        const seatNumber = row * rowLength + seat + 1;

        const seatCircle = new fabric.Circle({
          radius: seatRadius,
          fill: "#e0ffe4",
        });

        seatCircle.set("seatNumber", seatNumber);

        const seatLabel = new fabric.Text((seat + 1).toString(), {
          fontSize: 12,
          fill: "#000",
          left: seatRadius,
          top: seatRadius,
          originX: "center",
          originY: "center",
        });

        const seatGroupItem = new fabric.Group([seatCircle, seatLabel], {
          left: seat * (seatRadius * 2 + seatSpacing) + 30,
          top: row * (seatRadius * 2 + seatSpacing) + 30,
          selectable: false,
          seatNumber,
          id: this.idx,
        });

        this.grpArr.push(seatGroupItem);
        this.seatGroups.push(seatGroupItem);
        canvasRef.add(seatGroupItem);

        seatGroupItem.on("mousedown", () => {
          this.toggleSeatSelection(seatGroupItem);
          this.modifySeatNums(seatNumber, rowLength);
        });
      }
    }

    this.group = new fabric.Group(this.grpArr, {
      top: canvas.height / 2,
      left: canvas.width / 2,
      originX: "center",
      originY: "center",
    });
    canvasRef.add(this.group);
    this.groupAdded = true;

    this.group.on("mousedown", () => {
      // console.log(this.group.id);
    });

    canvasRef.renderAll();
  }

  seatEditing() {
    if (this.groupAdded) {
      this.canvasRef.remove(this.group);
      this.groupAdded = false;
    } else {
      this.canvasRef.add(this.group);
      this.groupAdded = true;
    }
    this.canvasRef.renderAll();
  }

  toggleSeatSelection(seatGroupItem) {
    const seatCircle = seatGroupItem.item(0);
    const isSelected = !seatCircle.get("selected");

    seatCircle.set({
      selected: isSelected,
      fill: isSelected ? "#ffcc00" : "#e0ffe4",
    });
  }

  modifySeatNums(seatNumber, cols) {
    const seatLabel = this.seatGroups[seatNumber - 1].item(1);
    if (seatLabel.text === "") {
      this.addSeats(seatNumber, cols);
    } else {
      this.removeSeats(seatNumber, cols);
    }
  }

  removeSeats(seatNumber, cols) {
    seatNumber = parseInt(seatNumber);
    cols = parseInt(cols);
    let start = seatNumber % cols;
    if (start === 0) start = cols;
    let j = seatNumber;
    let no = this.seatGroups[seatNumber - 1].item(1).text;
    for (let i = start; i < cols; i++, j++) {
      if (this.seatGroups[j].item(1).text === "") continue;
      else {
        this.seatGroups[j].item(1).set({ text: `${no}` });
        no++;
      }
    }

    this.seatGroups[seatNumber - 1].item(1).set({ text: "" });
  }

  addSeats(seatNumber, cols) {
    seatNumber = parseInt(seatNumber);
    cols = parseInt(cols);
    let start = seatNumber % cols;
    if (start === 0) start = cols;
    let no = 1;
    let j = seatNumber - start;

    for (let i = 0; i < cols; i++, j++) {
      if (this.seatGroups[j].item(1).text === "" && i !== start - 1) {
        continue;
      } else {
        this.seatGroups[j].item(1).set({ text: `${no}` });
        no++;
      }
    }
  }
}

export default SeatingObject;

// const radius = Math.min(canvasRef.width / 2, canvasRef.height / 2);
// const radius = 200;
// const startAngle = Math.PI/1.5;
// const endAngle = 0;

// this.createArc(centerPoint, radius, startAngle, endAngle, this.grpArr);

// createArc(centerPoint, radius, startAngle, endAngle, seatGroupItems) {
//   const angleStep = (endAngle - startAngle) / seatGroupItems.length;
//   let currentAngle = startAngle;

//   seatGroupItems.forEach((seatGroupItem) => {
//     const xOffset = Math.cos(currentAngle) * radius;
//     const yOffset = Math.sin(currentAngle) * radius;

//     seatGroupItem.set({
//       top: yOffset,
//       left: xOffset,
//       originX: "center",
//       originY: "center",
//     });
//     console.log(seatGroupItem);

//     currentAngle += angleStep;
//   });

//   this.canvasRef.renderAll();
// }
