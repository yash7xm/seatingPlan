import { useContext, useEffect, useState } from "react";
import "../assets/Styles/Setter.css";
import EditSection from "./EditSection";
import seatingObject from "../objects/seatingObject";
import CanvasContext from "../utils/canvasContext";

const Setter = () => {
  const [rows, setRows] = useState(5);
  const [cols, setCols] = useState(10);
  const [seatPlanName, setSeatPlanName] = useState("");
  const [height, setHeight] = useState(800);
  const [width, setWidth] = useState(800);
  const [sectionName, setSectionName] = useState("");
  const [enableEditSection, setEnableEditSection] = useState(false);

  const { canvas } = useContext(CanvasContext);

  const [seats, setSeats] = useState([]);
  const [idx, setIdx] = useState(0);
  const [id, setId] = useState(-1);
  const [editing, setEditing] = useState(false);

  const handleClick = () => {
    const setterOptions = {
      rowLength: Number(cols),
      rows: Number(rows),
      seatRadius: 12,
      seatSpacing: 4,
    };

    if (canvas) {
      const seating = new seatingObject(setterOptions, canvas, idx);
      seating.createSeats();
      canvas.renderAll();
      setIdx((prevstate) => prevstate + 1);
      const newArr = [...seats];
      newArr.push(seating);
      setSeats(newArr);

      // console.log(seating);
      // setSeats(seating);
    }
  };

  useEffect(() => {
    const handleMouseDown = function (e) {
      const clickedId =
        e.target._objects[0].id > -1 ? e.target._objects[0].id : e.target.id;

      if (clickedId !== id && !editing) {
        setId(clickedId);
        console.log(id);
        setEnableEditSection((prevState) => !prevState);
        setEditing((prevstate) => !prevstate);
      } else if (clickedId !== id && editing) {
        if (!seats[id].groupAdded) seats[id].seatEditing();
        setId(clickedId);
      }
    };

    if (canvas) {
      canvas.on("mouse:down", handleMouseDown);
    }

    return () => {
      canvas?.off("mouse:down", handleMouseDown);
    };
  }, [canvas, id]);

  return (
    <div className="cont-wrapper">
      <div className="controller">
        {enableEditSection ? (
          <EditSection seating={seats[id]} cancel={setEnableEditSection} />
        ) : (
          <>
            <div className="add-seatplan-card">
              <div className="name">
                <label htmlFor="seatplanName">Name:</label>
                <input
                  type="text"
                  placeholder="Cinema Screen 3"
                  id="seatplanName"
                  value={seatPlanName}
                  onChange={(e) => setSeatPlanName(e.target.value)}
                />
              </div>
              <div className="row-coloumn">
                <label htmlFor="width">Width:</label>
                <input
                  type="number"
                  placeholder="800"
                  id="width"
                  value={width}
                  onChange={(e) => setWidth(e.target.value)}
                />
                <label htmlFor="height">Height:</label>
                <input
                  type="number"
                  placeholder="800"
                  id="heigth"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                />
              </div>
              <div className="generate-btn">
                <button>Save Seat Plan</button>
              </div>
            </div>
            <div className="add-section-card">
              <div className="name">
                <label htmlFor="sectionName">Add Section:</label>
                <input
                  type="text"
                  placeholder="name"
                  id="sectionName"
                  value={sectionName}
                  onChange={(e) => setSectionName(e.target.value)}
                />
              </div>
              <div className="row-coloumn">
                <label htmlFor="rows">Rows:</label>
                <input
                  type="number"
                  placeholder="rows"
                  value={rows}
                  id="rows"
                  onChange={(e) => setRows(e.target.value)}
                />
                <label htmlFor="cols">Seats Per Row:</label>
                <input
                  type="number"
                  placeholder="columns"
                  id="cols"
                  value={cols}
                  onChange={(e) => setCols(e.target.value)}
                />
              </div>
              <div className="generate-btn">
                <button onClick={handleClick}>Add</button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Setter;
