import { useLayoutEffect, useContext } from "react";
import "../assets/Styles/Editor.css";
import { fabric } from "fabric";
import CanvasContext from "../utils/canvasContext";

const Editor = () => {
  const { setCanvas } = useContext(CanvasContext);
  useLayoutEffect(() => {
    const canvas = new fabric.Canvas("canvas", {
      height: 400,
      width: 800,
      fireRightClick: true,
      fireMiddleClick: true,
      stopContextMenu: true,
      backgroundColor: undefined,
      backgroundImage: undefined,
    });
    setCanvas(canvas);
    canvas.requestRenderAll();
    return () => {
      canvas.dispose();
    };
  }, []);

  return (
    <div className="view">
      <canvas id="canvas" />
    </div>
  );
};

export default Editor;
