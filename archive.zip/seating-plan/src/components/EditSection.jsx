import { useContext, useState } from "react";
import "../assets/Styles/EditSection.css";
import seatingObject from "../objects/seatingObject";
import CanvasContext from "../utils/canvasContext";

const EditSection = ({ seating, cancel }) => {
  const [sectionName, setSectionName] = useState("");
  const [seatSpacing, setSeatSpacing] = useState(4);

  const { canvas } = useContext(CanvasContext);

  const handleSeatEditing = () => {
    seating.seatEditing();
  };

  const handleCancelBtn = () => {
    cancel(false);
  };

  return (
    <div className="edit-section">
      <div className="edit-section-header">
        <div className="edit-section-title">Edit Section</div>
        <div className="edit-section-cancel-btn" onClick={handleCancelBtn}>
          Cancel
        </div>
      </div>
      <div className="name">
        <label htmlFor="sectionName">Add Section:</label>
        <input
          type="text"
          placeholder="name"
          id="sectionName"
          value={sectionName}
          onChange={(e) => setSectionName(e.target.value)}
        />
      </div>
      <div className="arc-section">
        <div className="arc-check">
          <label htmlFor="arcCheckBox">Arc:</label>
          <input type="checkbox" id="arcCheckBox" />
        </div>
        <div className="seat-spacing">
          <label htmlFor="seatSpacing">Seat Spacing:</label>
          <input
            type="range"
            id="seatSpacing"
            min="0"
            max="15"
            step="1"
            value={seatSpacing}
            onChange={(e) => setSeatSpacing(e.target.value)}
          />
        </div>
        <div className="seat-spacing">
          <label htmlFor="seatSpacing">Seat Size:</label>
          <input
            type="range"
            id="seatSpacing"
            min="0"
            max="15"
            step="1"
            value={seatSpacing}
            onChange={(e) => setSeatSpacing(e.target.value)}
          />
        </div>
        <div onClick={handleSeatEditing} className="activate-seat-editing-btn">
          <div>Activate Seat Editing</div>
        </div>
      </div>
    </div>
  );
};

export default EditSection;
