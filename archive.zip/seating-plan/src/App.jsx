import { useState, useEffect } from "react";
import "./App.css";
import Setter from "./components/Setter";
import Editor from "./components/Editor";
import CanvasContext from "./utils/canvasContext";

function App() {
  const [canvasVal, setCanvasVal] = useState();
  const setCanvas = function (canv) {
    setCanvasVal(canv);
  };

  return (
    <CanvasContext.Provider
      value={{
        canvas: canvasVal,
        setCanvas,
      }}
    >
      <div className="app-wrapper">
        <div className="app">
          <div className="header">Edit Seating Plans</div>
          <div className="app-body">
            <Setter />
            <Editor />
          </div>
          <div className="footer">
            <div className="del-btn">Delete</div>
            <div className="close-btn">Close</div>
          </div>
        </div>
      </div>
    </CanvasContext.Provider>
  );
}

export default App;
