import { createSlice } from "@reduxjs/toolkit";

const setterSlice = createSlice({
  name: "Setter",
  initialState: {
    rowLength: 10,
    rows: 5,
    seatRadius: 12,
    seatSpacing: 4,
    lastUpdate: null,
  },
  reducers: {
    setSeatsSpec: (state, action) => {
      const { rowLength, row } = action.payload;
      state.rowLength = rowLength;
      state.row = row;
      state.lastUpdate = Date.now();
    },
  },
});

export const { setSeatsSpec } = setterSlice.actions;
export default setterSlice.reducer;
