import { createContext } from "react";
import { fabric } from "fabric";

const CanvasContext = createContext({
  canvas: undefined,
  setCanvas: () => {},
});

export default CanvasContext;
