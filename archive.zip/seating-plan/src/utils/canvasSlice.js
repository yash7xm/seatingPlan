import { createSlice } from "@reduxjs/toolkit";

const canvasSlice = createSlice({
    name: 'canvas',
    initialState: {
        canvas: null,
    },
    reducers: {
        setCanvas: (state, action) => {
            state.canvas = action.payload
        },

        clearCanvas: (state) => {
            state.canvas = null;
        }
    }
})

export const {setCanvas, clearCanvas} = canvasSlice.actions;
export default canvasSlice.reducer;