import { configureStore } from "@reduxjs/toolkit";
import setterReducer from "./setterSlice";
import canvasReducer from './canvasSlice';

const appStore = configureStore({
    reducer: {
        setter: setterReducer,
        canvas: canvasReducer
    }
});

export default appStore;